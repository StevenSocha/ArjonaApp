document.addEventListener("DOMContentLoaded", () => {
    // --- Referencias UI ---
    const lblFecha = document.getElementById("lbl-fecha");
    const inpRemisionNo = document.getElementById("inp-remision-no");
    const productsBody = document.getElementById("products-body");
    const lblTotalGlobal = document.getElementById("lbl-total-global");

    const btnAddRow = document.getElementById("btn-add-row");
    const btnPrint = document.getElementById("btn-print");
    const btnNew = document.getElementById("btn-new");
    const btnSave = document.getElementById("btn-save");

    const historyList = document.getElementById("history-list");
    const chkDoublePrint = document.getElementById("chk-double-print");
    const printArea = document.getElementById("print-area");

    // Inputs principales para guardar
    const inputs = {
        op: document.getElementById("inp-op"),
        oc: document.getElementById("inp-oc"),
        factura: document.getElementById("inp-factura"),
        lote: document.getElementById("inp-lote-header"),
        cliente: document.getElementById("inp-cliente"),
        contacto: document.getElementById("inp-contacto"),
        direccion: document.getElementById("inp-direccion"),
        observaciones: document.getElementById("inp-observaciones")
    };

    // --- Inicialización ---
    initSystem();

    function initSystem() {
        setFecha();
        setRemisionNumber();
        renderHistory();
        updateIndexAndTotal();
    }

    function setFecha() {
        const hoy = new Date();
        const dd = String(hoy.getDate()).padStart(2, '0');
        const mm = String(hoy.getMonth() + 1).padStart(2, '0');
        const yyyy = hoy.getFullYear();
        lblFecha.textContent = `${dd}/${mm}/${yyyy}`;
    }

    function setRemisionNumber() {
        const lastNo = localStorage.getItem("last_remision_no") || "1024";
        inpRemisionNo.value = parseInt(lastNo, 10) + 1;
    }

    function updateIndexAndTotal() {
        const rows = productsBody.querySelectorAll("tr");
        rows.forEach((row, index) => {
            const indexCell = row.querySelector(".item-index");
            if (indexCell) indexCell.textContent = index + 1;
        });
        lblTotalGlobal.textContent = rows.length;
    }

    window.addRow = function () {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td class="text-center item-index"></td>
            <td><input type="text" placeholder="Descripción del producto"></td>
            <td><input type="text" placeholder="-"></td>
            <td><input type="number" class="qty-input" placeholder="0"></td>
            <td><input type="text" placeholder="Unidades"></td>
            <td class="no-print text-center empty-print-hide">
                <button class="btn-delete" onclick="deleteRow(this)">×</button>
            </td>
        `;
        productsBody.appendChild(tr);
        updateIndexAndTotal();
    };

    window.deleteRow = function (btn) {
        const row = btn.closest("tr");
        if (productsBody.querySelectorAll("tr").length > 1) {
            row.remove();
            updateIndexAndTotal();
        } else {
            alert("La remisión debe tener al menos un ítem.");
        }
    };

    // --- Historial LocalStorage ---
    function saveToHistory() {
        if (!inputs.cliente.value.trim()) {
            alert("Por favor ingrese el nombre del cliente antes de guardar.");
            return;
        }

        const remisiones = JSON.parse(localStorage.getItem("remisiones_history") || "[]");
        const nuevaRemision = {
            id: Date.now(),
            numero: inpRemisionNo.value,
            fecha: lblFecha.textContent,
            cliente: inputs.cliente.value,
            observaciones: inputs.observaciones.value
        };

        remisiones.push(nuevaRemision);
        localStorage.setItem("remisiones_history", JSON.stringify(remisiones));
        localStorage.setItem("last_remision_no", inpRemisionNo.value);

        renderHistory();
        alert(`Remisión No. ${inpRemisionNo.value} guardada con éxito.`);
    }

    function renderHistory() {
        historyList.innerHTML = "";
        const remisiones = JSON.parse(localStorage.getItem("remisiones_history") || "[]");

        if (remisiones.length === 0) {
            historyList.innerHTML = `<li style="padding:1rem; font-size:0.8rem; color:#888; text-align:center;">Ninguna remisión guardada</li>`;
            return;
        }

        remisiones.reverse().forEach(rem => {
            const li = document.createElement("li");
            li.className = "history-item";
            li.innerHTML = `
                <div class="item-title">Remisión #${rem.numero}</div>
                <div class="item-meta">
                    <span>${rem.cliente.substring(0, 18)}...</span>
                    <span>${rem.fecha}</span>
                </div>
            `;
            li.addEventListener("click", () => {
                alert(`Visualizando datos informativos de Remisión No. ${rem.numero}`);
            });
            historyList.appendChild(li);
        });
    }

    function clearForm() {
        Object.values(inputs).forEach(inp => inp.value = "");
        document.querySelector(".inp-transport-nombre").value = "";
        document.querySelector(".inp-transport-doc").value = "";
        document.querySelector(".inp-transport-placa").value = "";

        productsBody.innerHTML = `
            <tr>
                <td class="text-center item-index">1</td>
                <td><input type="text" placeholder="Ej. Jabón de tocador base"></td>
                <td><input type="text" placeholder="-"></td>
                <td><input type="number" class="qty-input" placeholder="0"></td>
                <td><input type="text" placeholder="Unidades"></td>
                <td class="no-print text-center empty-print-hide">
                    <button class="btn-delete" onclick="deleteRow(this)">×</button>
                </td>
            </tr>
        `;
        setFecha();
        setRemisionNumber();
        updateIndexAndTotal();
    }

    // --- Impresión Doble Sincronizada ---
    let cloneDoc = null;

    window.onbeforeprint = () => {
        if (chkDoublePrint.checked) {
            document.body.classList.add("print-double");
            const originalDoc = document.getElementById("remision-doc");
            cloneDoc = originalDoc.cloneNode(true);
            cloneDoc.id = "remision-doc-clone";

            // Sincronizar todos los inputs y campos editables en la copia clonada
            const origInputs = originalDoc.querySelectorAll('input, textarea, select');
            const cloneInputs = cloneDoc.querySelectorAll('input, textarea, select');
            origInputs.forEach((inp, i) => {
                cloneInputs[i].value = inp.value;
            });

            printArea.appendChild(cloneDoc);
        }
    };

    window.onafterprint = () => {
        if (cloneDoc) {
            printArea.removeChild(cloneDoc);
            cloneDoc = null;
        }
        document.body.classList.remove("print-double");
    };

    // --- Vinculación de Eventos ---
    btnAddRow.addEventListener("click", () => window.addRow());
    btnPrint.addEventListener("click", () => window.print());
    btnSave.addEventListener("click", () => saveToHistory());
    btnNew.addEventListener("click", () => {
        if (confirm("¿Crear nueva remisión? Se limpiarán los datos del formato.")) {
            clearForm();
        }
    });
});
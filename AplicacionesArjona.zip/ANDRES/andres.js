document.addEventListener('DOMContentLoaded', () => {
    const remissionInput = document.getElementById('remissionNumber');
    const dateInput = document.getElementById('remissionDate');
    const btnPrint = document.getElementById('btn-print');
    const btnDownload = document.getElementById('btn-download');
    const btnClear = document.getElementById('btn-clear');
    const historyList = document.getElementById('history-list');

    // New Feature elements
    const togglePh = document.getElementById('toggle-ph');
    const phRow = document.getElementById('ph-row');

    // Botones dinámicos de inserción de filas
    const btnAddProduct = document.getElementById('btn-add-product');
    const btnAddMicro = document.getElementById('btn-add-micro');
    const btnAddFq = document.getElementById('btn-add-fq');

    // Contenedores de las tablas
    const productsBody = document.getElementById('products-body');
    const microBody = document.getElementById('micro-body');
    const fqBody = document.getElementById('fq-body');

    let history = JSON.parse(localStorage.getItem('remissionHistory')) || [];

    // 1. Initialize Date
    const setTodayDate = () => {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        dateInput.value = `${yyyy}-${mm}-${dd}`;
    };

    // 2. Initialize Remission Number
    const loadRemissionNumber = () => {
        const lastSaved = localStorage.getItem('lastRemissionNumber');
        if (lastSaved) {
            remissionInput.value = parseInt(lastSaved, 10) + 1;
        } else {
            remissionInput.value = 1;
        }
    };

    // 3. Render History
    const renderHistory = () => {
        historyList.innerHTML = '';
        if (history.length === 0) {
            historyList.innerHTML = '<li style="padding: 15px; text-align: center; color: #64748b; font-size: 12px;">No hay remisiones guardadas</li>';
            return;
        }

        const reversed = [...history].reverse();
        reversed.forEach(item => {
            const li = document.createElement('li');
            li.className = 'history-item';
            li.innerHTML = `
                <input type="checkbox" data-id="${item.id}">
                <div class="history-info" onclick="loadHistoryItem(${item.id})">
                    <span class="num">Remisión #${item.remissionNumber}</span>
                    <span class="date">${item.date}</span>
                    <span class="client">${item.product || 'Sin producto'}</span>
                </div>
            `;
            historyList.appendChild(li);
        });
    };

    // Save to history helper
    const saveCurrentToHistory = () => {
        const num = remissionInput.value;
        const date = dateInput.value;
        const firstProductInput = document.querySelector('.products-table tbody tr:first-child td:nth-child(2) input');
        const product = firstProductInput ? firstProductInput.value : '';

        // Avoid exact duplicates
        const exists = history.some(h => h.remissionNumber == num && h.date == date);
        if (!exists) {
            history.push({
                id: Date.now(),
                remissionNumber: num,
                date: date,
                product: product || 'Sin producto'
            });
            localStorage.setItem('remissionHistory', JSON.stringify(history));
            localStorage.setItem('lastRemissionNumber', num);
            renderHistory();
        }
    };

    // Initial calls
    setTodayDate();
    loadRemissionNumber();
    renderHistory();

    // pH Toggle Logic
    if (togglePh && phRow) {
        togglePh.addEventListener('change', (e) => {
            if (e.target.checked) {
                phRow.style.display = ''; // Show
            } else {
                phRow.style.display = 'none'; // Hide entirely
            }
        });
    }

    // --- FUNCIONALIDAD: AGREGAR NUEVAS FILAS DINÁMICAMENTE ---

    // Agregar Fila a Tabla de Productos
    if (btnAddProduct && productsBody) {
        btnAddProduct.addEventListener('click', () => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="number"></td>
                <td><input type="text" value=""></td>
                <td><input type="date"></td>
                <td>
                    <select>
                        <option value="SI">SI</option>
                        <option value="NO">NO</option>
                    </select>
                </td>
                <td><input type="text"></td>
                <td><input type="text"></td>
                <td class="no-print text-center border-none"><button class="btn-icon btn-delete-row" title="Eliminar fila">×</button></td>
            `;
            productsBody.appendChild(tr);
        });
    }

    // Agregar Fila a Análisis Microbiológico
    if (btnAddMicro && microBody) {
        btnAddMicro.addEventListener('click', () => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" value=""></td>
                <td class="text-center" style="width: 25%"><input type="text" value=""></td>
                <td class="text-center" style="width: 25%"><input type="text" value="g / mL"></td>
                <td class="no-print text-center border-none"><button class="btn-icon btn-delete-row" title="Eliminar fila">×</button></td>
            `;
            microBody.appendChild(tr);
        });
    }

    // Agregar Fila a Análisis Físico Químico
    if (btnAddFq && fqBody) {
        btnAddFq.addEventListener('click', () => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" value=""></td>
                <td class="text-center"><input type="text" value=""></td>
                <td class="text-center"><input type="text" value="-"></td>
                <td class="no-print text-center border-none"><button class="btn-icon btn-delete-row" title="Eliminar fila">×</button></td>
            `;
            // Insertar justo antes de la fila de pH si existe, si no, al final
            if (phRow) {
                fqBody.insertBefore(tr, phRow);
            } else {
                fqBody.appendChild(tr);
            }
        });
    }

    // Row Deletion Logic (Delegated event listener for dynamically acting on rows)
    document.querySelector('.document-container').addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-delete-row')) {
            const row = e.target.closest('tr');
            if (row) {
                row.remove();
            }
        }
    });

    // Make loadHistoryItem available globally so inline onclick works
    window.loadHistoryItem = (id) => {
        const item = history.find(h => h.id === id);
        if (item) {
            remissionInput.value = item.remissionNumber;
            dateInput.value = item.date;
        }
    };

    // 4. Print Action
    btnPrint.addEventListener('click', () => {
        saveCurrentToHistory();
        window.print();
        setTimeout(loadRemissionNumber, 1500);
    });

    // 5. Download Action (PDF)
    btnDownload.addEventListener('click', () => {
        const element = document.getElementById('document-content');
        const num = remissionInput.value;

        element.classList.add('pdf-mode');

        // Dynamically adjust dimensions for pdf scaling if needed
        const opt = {
            margin: 0,
            filename: `Orden_Remision_${num}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'mm', format: [320, 230], orientation: 'landscape' } // Matches new width/height
        };

        const originalText = btnDownload.innerHTML;
        btnDownload.innerHTML = 'Generando PDF...';
        btnDownload.disabled = true;

        html2pdf().set(opt).from(element).save().then(() => {
            saveCurrentToHistory();
            element.classList.remove('pdf-mode');
            btnDownload.innerHTML = originalText;
            btnDownload.disabled = false;
            setTimeout(loadRemissionNumber, 1500);
        }).catch(err => {
            console.error("Error generating PDF", err);
            element.classList.remove('pdf-mode');
            btnDownload.innerHTML = originalText;
            btnDownload.disabled = false;
            alert("Hubo un error al generar el PDF.");
        });
    });

    // 6. Delete Selected History
    document.getElementById('btn-del-selected').addEventListener('click', () => {
        const checkboxes = document.querySelectorAll('.history-item input[type="checkbox"]:checked');
        if (checkboxes.length === 0) {
            alert('Selecciona al menos un elemento para eliminar.');
            return;
        }

        if (confirm('¿Eliminar las remisiones seleccionadas del historial?')) {
            const idsToDelete = Array.from(checkboxes).map(cb => parseInt(cb.getAttribute('data-id')));
            history = history.filter(item => !idsToDelete.includes(item.id));
            localStorage.setItem('remissionHistory', JSON.stringify(history));
            renderHistory();
        }
    });

    // 7. Delete All History
    document.getElementById('btn-del-all').addEventListener('click', () => {
        if (history.length === 0) return;

        if (confirm('¿Estás seguro de eliminar TODO el historial? Esta acción no se puede deshacer.')) {
            history = [];
            localStorage.setItem('remissionHistory', JSON.stringify(history));
            renderHistory();
        }
    });

    // 8. Restore Defaults Action (Changed from just Clear)
    btnClear.addEventListener('click', () => {
        if (confirm('¿Recargar la página para restaurar todos los valores y filas por defecto?')) {
            window.location.reload();
        }
    });
});